# Digital_clock
It is to display the time <br>
Click the below link to open this project:
# https://prasadg86.github.io/Digital_clock/
